# Ajustes de revisión (14/10/2026)

Esta versión conserva la arquitectura del ZIP recibido y aplica dos correcciones puntuales:

1. **Registro MLflow** (`src/stages.py`): antes de crear una versión del campeón,
   busca una versión existente con la misma `version_key` (hash de `run_key`,
   modelo, datos, configuración y commit). Si existe, la reutiliza. Evita
   versiones duplicadas al repetir la tarea de registro tras un fallo.
   **Límite:** dos ejecuciones simultáneas aún podrían competir; en un despliegue
   productivo se requeriría un bloqueo o serialización de esta tarea.
2. **Validación temporal** (`src/validation.py`): lee `p_fecinformacion` en formato
   YYYYMMDD, rechaza fechas inválidas o ausentes y documenta los rangos por
   partición. Avisa sobre solapamientos entre archivos consecutivos.
   Para exigir rangos sin solapamientos, añadir:
   `validation.strict_temporal_order: true` en `config/config.yaml`,
   solo si el negocio confirma que las ventanas son estrictamente disjuntas.

## Antes de ejecutar

- Copiar `.env.example` a `.env` y revisar valores; el `.env` recibido no se
  distribuye en este ZIP por precaución.
- Colocar los diez CSV originales en `data/input/` (no incluidos).
- Ejecutar `docker compose build` y `docker compose up -d`.
- Abrir Airflow en http://localhost:8080 y MLflow en http://localhost:5000.
- Lanzar una corrida de prueba con `n_trials=2` y una fracción pequeña de datos.
- Repetir **la misma clave `run_key`** y verificar que no crezcan los runs ni las
  versiones del modelo. Una clave distinta representa otra corrida.
- Tomar capturas de las interfaces y registrar resultados reales en el README.

## Verificaciones realizadas

Se comprobó la sintaxis de los archivos `.py` con el parser de Python.
**No se ejecutó** el pipeline con los CSV reales ni se verificó Docker en Windows.
No considerar este ZIP como validación funcional completa.

---
# Ajustes de verificación contra el enunciado del parcial (15/10/2026)

- `src/validation.py`: la regex que quita el sufijo `.0` de `p_fecinformacion` estaba mal escapada; con fechas leídas como
  float todas se marcaban inválidas y la compuerta cortaba el DAG con datos correctos.
- `src/provenance.py`: `GIT_COMMIT=unknown` (valor por defecto del compose) se trata como ausente y se consulta git; nuevo tag `airflow_dag_run_id`.
- `Dockerfile`/`docker-compose.yml`: git en la imagen, `safe.directory`, `SECRET_KEY` del webserver (recuperado de la versión local),
  salidas en `./data/output` (bind mount) en vez de un volumen oculto.
- `dags/training_dag.py` (antes `automl_training_dag.py`): reintentos/pool/timeout desde `config.yaml` (`airflow:`), `run_key` determinista, tarea `generate_report`.
- `src/monitoring.py` (antes `compute_logger.py`): `gpu_available` y `cpu_cores_logical` explícitos; tag `compute_mode`.
- `src/stages.py`: modelo serializado y curva ROC como artefactos; criterio de GetBestModel en MLflow; `generate_report`
  (`results_summary.json`, `compute_logs.json`, `report.md`); promoción con `registry.min_margin` y alias `challenger`.
- `src/backtesting.py`: `drift_alert` por ola.
- `.gitignore`: ya no excluye `data/output/` (se exige al menos una corrida completa en el repo).
- `tests/smoke_pipeline.py`: fechas YYYYMMDD y nuevas comprobaciones (pasa completo con datos sintéticos).
- `docs/decisiones_diseno.md`, `README.md`, `docs/img/README.md`: actualizados.
