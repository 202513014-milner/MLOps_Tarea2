# Capturas de evidencia (completar tras ejecutar el DAG)

Guardar aquí, con estos nombres:

- `airflow_dag_ok.png` — Airflow (http://localhost:8080): DAG `automl_training_pipeline` con todas las tareas en verde.
- `mlflow_runs.png` — MLflow (http://localhost:5000): lista de runs del experimento `automl-venta-financiera`.
- `mlflow_comparacion.png` — comparación de modelos (`hpo/<modelo>`) por la métrica primaria.
- `mlflow_registry.png` — Model Registry con los alias `champion` / `challenger`.
- `idempotencia.png` — segunda ejecución del DAG: tareas saltadas y mismo número de runs.
