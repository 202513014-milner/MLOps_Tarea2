"""Prueba de integración del pipeline P3 con datos sintéticos (sin Airflow ni Docker).

Verifica: compuerta de validación, las 8 etapas, trazabilidad en MLflow (commit, hash de datos,
imagen Docker, config, ejecución del DAG), logs de cómputo, idempotencia (segunda ejecución salta;
reintento tras fallo no duplica runs), GetBestModel por métrica de negocio y promoción en el registro.

Ejecutar:  python tests/smoke_pipeline.py
"""
import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def hacer_datos(directorio, filas=3000, seed=0, corromper=None):
    rng = np.random.default_rng(seed)
    for i in range(1, 11):
        x1, x2, x3 = rng.normal(size=(3, filas))
        logit = -2.6 + 1.1 * x1 - 0.8 * x2 + 0.5 * x3 * (i / 10)  # leve deriva en el tiempo
        y = (rng.random(filas) < 1 / (1 + np.exp(-logit))).astype(int)
        df = pd.DataFrame({'partition': i, 'tip_doc': 1, 'key_value': np.arange(filas), 'codunicocli': np.arange(filas),
                           'prob_value_contact': rng.random(filas), 'fch_creacion': '2026-01-01',
                           'p_fecinformacion': 20260000 + i * 100 + 28, 'monto': x1 * 100 + 500, 'ingreso_neto': x2 * 50 + 2000,
                           'tea': x3, 'ruido': rng.normal(size=filas),
                           'ent_1erlntcrallsfm01': rng.choice(['A', 'B', 'C', None], filas),
                           'grp_campecs06m': rng.choice(['G1', 'G2', 'G3'], filas), 'target': y})
        df.loc[rng.random(filas) < 0.1, 'ingreso_neto'] = np.nan
        if corromper == i:
            df['target'] = 0  # tasa de positivos 0 -> la compuerta debe rechazarlo
        df.to_csv(Path(directorio) / f'p{i}_extrac.csv', index=False)


def configuracion(tmp):
    from src.stages import cargar_config
    over = {'input_dir': str(Path(tmp) / 'input'), 'output_dir': str(Path(tmp) / 'output'),
            'sample_fraction': 0.5, 'hpo': {'cv_folds': 2, 'verbose': 0, 'optuna': {'n_trials': 3, 'timeout_seconds': 60}},
            'parallel': {'workers': 2}, 'backtesting': {'sample_fraction': 0.5},
            'compute_logging': {'interval_seconds': 0.5},
            'validation': {'min_rows': 500, 'min_positive_rate': 0.005}}
    return cargar_config('config/config.yaml', over)


def main():
    os.environ['GIT_COMMIT'] = 'abc1234deadbeef'
    os.environ['GIT_BRANCH'] = 'main'
    os.environ['DOCKER_IMAGE'] = 'automl-mlops:test'
    os.environ['AIRFLOW_CTX_DAG_ID'] = 'automl_training_pipeline'
    os.environ['AIRFLOW_CTX_DAG_RUN_ID'] = 'manual__test'
    with tempfile.TemporaryDirectory() as tmp:
        os.chdir(tmp)  # los artefactos por defecto de MLflow (./mlruns) caen en el directorio temporal
        os.environ['MLFLOW_TRACKING_URI'] = f'sqlite:///{Path(tmp, "mlflow.db").as_posix()}'
        Path(tmp, 'input').mkdir()
        hacer_datos(Path(tmp, 'input'))
        from src import stages
        from src.validation import DataValidationError
        cfg = configuracion(tmp)
        key = 'manual__prueba'

        # 1) La compuerta rechaza datos malos y no deja _SUCCESS
        bad = Path(tmp, 'bad'); bad.mkdir(); hacer_datos(bad, corromper=3)
        try:
            stages.validate_data({**cfg, 'input_dir': str(bad)}, 'bad_run')
        except DataValidationError as exc:
            assert 'p3_extrac.csv' in str(exc), exc
        else:
            raise AssertionError('La compuerta debió rechazar el CSV corrupto')
        assert not (stages.dir_etapa(cfg, 'bad_run', 'validate_data') / '_SUCCESS.json').exists()
        print('PASS: compuerta de validación bloquea datos corruptos.')

        # 2) Pipeline completo
        stages.validate_data(cfg, key)
        stages.prepare_data(cfg, key)
        for m in stages.MODELOS:
            stages.hpo_model(cfg, key, m)
        stages.select_hpo(cfg, key)
        bench = stages.benchmark(cfg, key)
        best = stages.get_best_model_stage(cfg, key)
        stages.backtesting(cfg, key)
        promo = stages.register_champion(cfg, key)
        rep = stages.generate_report(cfg, key)
        raiz = stages.raiz_corrida(cfg, key)
        for f in ('results_summary.json', 'compute_logs.json', 'report.md'):
            assert (raiz / f).exists(), f
        cl = json.loads((raiz / 'compute_logs.json').read_text())
        assert cl['compute_mode'] in ('cpu_only', 'gpu') and len(cl['models']) == 9 and 'hpo/xgb' in cl['tasks']
        assert all(m['model_size_mb'] for m in cl['models'].values())
        print(f'PASS: generate_report escribe compute_logs.json, results_summary.json y report.md en {raiz.name}.')
        assert bench['speedup'] > 0 and promo['promoted'] and best['consistent_with_benchmark']
        print(f'PASS: 9 etapas OK | campeón={best["champion"]} | speed-up={bench["speedup"]:.2f}')

        # 3) Trazabilidad y cómputo en MLflow
        import mlflow
        from mlflow.tracking import MlflowClient
        mlflow.set_tracking_uri(os.environ['MLFLOW_TRACKING_URI'])
        client = MlflowClient()
        exp = client.get_experiment_by_name(cfg['mlflow']['experiment'])
        all_runs = client.search_runs([exp.experiment_id], max_results=200)
        failed = [r for r in all_runs if r.info.status == 'FAILED']
        assert len(failed) == 1 and failed[0].data.tags['validation_ok'] == 'false', 'la compuerta debe quedar registrada como run FAILED'
        runs = [r for r in all_runs if r.info.status == 'FINISHED']
        keys = [r.data.tags['idempotency_key'] for r in runs]
        assert len(keys) == len(set(keys)), 'runs duplicados'
        must = ['git_commit', 'git_branch', 'data_hash', 'docker_image', 'config_hash', 'airflow_dag_id', 'airflow_dag_run_id', 'run_key']
        for r in runs:
            for t in must:
                assert t in r.data.tags and r.data.tags[t] not in ('', 'unknown'), (r.info.run_name, t)
            assert r.data.tags['git_commit'] == 'abc1234deadbeef' and r.data.tags['docker_image'] == 'automl-mlops:test'
            assert 'compute.wall_seconds' in r.data.metrics and 'compute.ram_rss_mb_max' in r.data.metrics, r.info.run_name
            assert 'compute.cpu_percent_avg' in r.data.metrics
        hpo_runs = [r for r in runs if r.data.tags['etapa'] == 'hpo']
        assert len(hpo_runs) == 9 and all('model_size_mb' in r.data.metrics for r in hpo_runs)
        assert all(r.data.tags['compute_mode'] in ('cpu_only', 'gpu') for r in runs)
        assert all(r.data.metrics.get('compute.gpu_available') in (0.0, 1.0) for r in runs)
        arts = {a.path for a in client.list_artifacts(hpo_runs[0].info.run_id, 'hpo')}
        assert any(a.endswith('_roc.png') for a in arts) and client.list_artifacts(hpo_runs[0].info.run_id, 'model')
        data_hashes = {r.data.tags['data_hash'] for r in runs}
        assert len(data_hashes) == 1
        print(f'PASS: {len(runs)} runs trazables (commit, hash datos, imagen, config, DAG) con CPU/RAM/tiempos/tamaño.')

        # 3b) run_key determinista y commit con GIT_COMMIT=unknown (docker compose sin scripts/up.py)
        from src.provenance import git_info
        k1, k2 = stages.run_key_por_defecto(cfg), stages.run_key_por_defecto(cfg)
        assert k1 == k2 and k1.startswith('auto-'), (k1, k2)
        os.environ['GIT_COMMIT'] = 'unknown'
        assert git_info()['git_commit'] != 'unknown' or not Path(stages.ROOT, '.git').exists()
        os.environ['GIT_COMMIT'] = 'abc1234deadbeef'
        print('PASS: run_key por defecto determinista; GIT_COMMIT=unknown se trata como ausente.')

        # 4) Idempotencia: relanzar con el mismo run_key salta todo y no duplica runs
        again = stages.hpo_model(cfg, key, 'xgb')
        assert again['cached'] is True
        assert stages.prepare_data(cfg, key)['cached'] is True
        # Forzar una etapa sustituye su run (misma idempotency_key) en vez de duplicar
        before = len(client.search_runs([exp.experiment_id], max_results=500))
        stages.hpo_model(cfg, key, 'lgbm', force=True)
        after = len(client.search_runs([exp.experiment_id], max_results=500))
        assert before == after, (before, after)
        # Si cambian los datos, la huella cambia y se recalcula
        hacer_datos(Path(tmp, 'input'), seed=99)
        stages.validate_data(cfg, key)
        assert stages.prepare_data(cfg, key)['cached'] is False
        print('PASS: idempotencia (salto por huella, reemplazo de runs, invalidación por cambio de datos).')

        # 5) Un intento parcial se limpia: se simula un crash dejando basura sin _SUCCESS
        d = stages.dir_etapa(cfg, key, 'hpo', 'xgb')
        (d / '_SUCCESS.json').unlink(missing_ok=True)
        (d / 'basura_parcial.tmp').write_text('x')
        stages.prepare_data(cfg, key)  # sin cambios -> cached
        stages.hpo_model(cfg, key, 'xgb')
        assert not (d / 'basura_parcial.tmp').exists()
        print('PASS: un intento parcial se borra y se rehace.')

        # 6) Registro: segunda versión con peor métrica no se promueve
        reg = cfg['registry']
        c = MlflowClient()
        alias_v = str(c.get_model_version_by_alias(reg['model_name'], reg['alias']).version)
        assert alias_v == promo['version'], (alias_v, promo)
        print(f'PASS: alias {reg["alias"]} -> v{alias_v} en el Model Registry.')
        # Un candidato peor que el campeón vigente se registra pero NO se promueve
        c.set_model_version_tag(reg['model_name'], alias_v, 'capture_rate_top_k', '0.99')
        worse = stages.register_champion(cfg, key, force=True)
        assert worse['promoted'] is False and str(c.get_model_version_by_alias(reg['model_name'], reg['alias']).version) == alias_v
        assert str(c.get_model_version_by_alias(reg['model_name'], reg['challenger_alias']).version) == worse['version']
        print('PASS: un candidato peor no desplaza al campeón vigente y queda con el alias challenger.')
        print('\nTODAS LAS PRUEBAS PASARON')


if __name__ == '__main__':
    main()
