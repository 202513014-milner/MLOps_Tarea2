import os
os.environ["MPLBACKEND"] = "Agg"
from pathlib import Path
import tempfile,sys,json,pickle,hashlib
import numpy as np,pandas as pd,yaml
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.backtesting import run_backtesting
from src.registry import leer_json_compatible

def main():
 root=Path(__file__).resolve().parents[1];readme=root/'README.md'; original=readme.read_text(encoding='utf-8')
 try:
  with tempfile.TemporaryDirectory() as tmp:
   t=Path(tmp);source=t/'source';source.mkdir();inputs=t/'input';inputs.mkdir()
   config=yaml.safe_load((root/'config/config.yaml').read_text())
   config['input_dir']=str(inputs);config['output_dir']=str(t/'out')
   config['backtesting'].update(source_run_dir=str(source),cutoff_period='2023-06',sample_fraction=.5)
   config['temporal']['file_periods']={f'p{i}_extrac.csv':f'2023-{i:02d}' for i in range(6,11)}
   X=pd.DataFrame({'x':np.linspace(-3,3,200)});y=(X.x>0).astype(int)
   model=Pipeline([('preprocessing',Pipeline([('impute',SimpleImputer()),('scale',StandardScaler())])),('model',LogisticRegression())]).fit(X,y)
   path=source/'logistic_regression_model.pkl';path.write_bytes(pickle.dumps(model));before=hashlib.sha256(path.read_bytes()).hexdigest()
   manifest={'development':[{'file':f'p{i}_extrac.csv'} for i in range(1,7)],'reserved_backtesting_files':config['temporal']['backtesting_files'],'feature_columns':['x'],'development_periods':[]}
   (source/'results_summary.json').write_bytes(json.dumps({'campeon':'logistic_regression','comentario':'validación'},ensure_ascii=False).encode('cp1252'))
   (source/'logistic_regression_metadata.json').write_bytes(json.dumps({'performance':{'auc_test':.85},'data_split':manifest},ensure_ascii=False).encode('cp1252'))
   assert leer_json_compatible(source/'results_summary.json')['comentario']=='validación'
   for i in range(7,11):pd.DataFrame({'x':X.x,'target':y}).to_csv(inputs/f'p{i}_extrac.csv',index=False)
   with patch.object(Pipeline,'fit',side_effect=AssertionError('No debe reentrenar')):
    out,result=run_backtesting(config)
   assert result['chronology_verified'] and result['valid_waves']==4 and result['model_refitted'] is False
   assert all(r['rows_evaluated']==100 for r in result['waves'])
   assert all(abs(r['decay_percent']-100*(.85-r['auc'])/.85)<1e-9 for r in result['waves'])
   assert hashlib.sha256(path.read_bytes()).hexdigest()==before
   assert Path(out,'auc_por_ola.png').stat().st_size>1000
   # Solo existen p7..p10: demuestra que backtesting no necesita cargar p1..p6.
   pd.DataFrame({'x':X.x,'target':np.zeros(200,dtype=int)}).to_csv(inputs/'p8_extrac.csv',index=False)
   _,partial=run_backtesting(config)
   assert partial['valid_waves']==3 and partial['waves'][1]['auc'] is None
   config['temporal']['file_periods']['p9_extrac.csv']='2023-10'
   try:run_backtesting(config)
   except ValueError:pass
   else:raise AssertionError('No se rechazó un mes fuera de orden')
   # Notebook autónomo, sin ejecutar celda interactiva de subida.
   notebook=json.loads((root/'notebooks/backtesting_analysis.ipynb').read_text())
   import matplotlib.pyplot as plt
   ns={'results':result,'np':np,'plt':plt}
   exec(''.join(notebook['cells'][3]['source']),ns)
   print('PASS: campeón fijo sin fit, cuatro olas, muestreo, decay, PNG, notebook, JSON cp1252, AUC de una clase null y cronología inválida rechazada.')
 finally:readme.write_text(original,encoding='utf-8')
if __name__=='__main__':main()
