# Validación de esta versión
Se probó con datos sintéticos: HPO de nueve modelos con grillas reducidas, reutilización de ganadores sin GridSearch en paralelismo, dos procesos con PIDs distintos, tiempos positivos y speed-up calculado, nueve modelos/metadata, rechazo de fuente inexistente o configuración incompatible y exclusión de cuatro CSV futuros deliberadamente ilegibles. Se comprobó también que HPO=false y parallel=false no cargan datos. La comprobación XGBoost rechaza reportar CPU como GPU.

Ejecutar prueba de integración: `python tests/smoke_parallel.py`. Utiliza carpeta temporal, fuerza ruta CPU para ser independiente del hardware, restaura README y no altera config. No debe confundirse con evidencia de la corrida real de entrega.

No hay GPU física en el entorno de verificación: los backends CUDA/OpenCL requieren validación adicional en el equipo del usuario o Colab. La ejecución incluye preflight GPU y se detiene si detecta hardware pero ningún backend funcional. Tampoco se realizó ejecución con los CSV reales ni prueba en Windows.

## Backtesting
Se probó con datos sintéticos: cuatro olas, campeón fijo y fit bloqueado durante evaluación, muestra estratificada, fórmula del decay, hash del modelo sin cambios, PNG y código gráfico del notebook. Los CSV 1–6 no estaban presentes. Lectura de JSON cp1252, AUC null ante una sola clase y rechazo de periodos futuros incorrectos también verificados. Ejecutar `python tests/smoke_backtesting.py`. No equivale a validación con los CSV reales.

## Práctica 3 (MLOps)
Probado con datos sintéticos (no con los CSV reales):
- `python tests/smoke_pipeline.py`: compuerta de validación (rechaza CSV corrupto), las 8 etapas, trazabilidad en MLflow
  (commit, hash de datos, imagen, config, DAG), métricas de cómputo, idempotencia (salto por huella, reemplazo de runs,
  invalidación por cambio de datos, limpieza de intentos parciales), registro y promoción del campeón.
- DAG `automl_training_pipeline` ejecutado con `airflow dags test` en Airflow 2.10.5 (Python 3.11) contra un servidor MLflow
  3.17 por HTTP: las 14 tareas en SUCCESS; una segunda ejecución con la misma `run_key` salta todas las etapas.
- Los tests de la P2 (`smoke_parallel.py`, `smoke_backtesting.py`) siguen pasando.

No verificado todavía: `docker compose build/up` (la imagen base no se pudo descargar en el entorno de desarrollo; el
`docker-compose.yml` solo se validó sintácticamente), ejecución con los CSV reales, GPU y ejecución en Windows.
