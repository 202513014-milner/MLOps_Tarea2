"""Etapas del pipeline de entrenamiento: una función por tarea del DAG (D3).

Todas son **idempotentes** (D7):
- Cada corrida del DAG tiene un ``run_key`` (por defecto el run_id de Airflow, saneado).
- Las salidas de una etapa viven en ``<output_dir>/runs/<run_key>/<etapa>[/models/<m>]/``.
- Una etapa solo se salta si existe ``_SUCCESS.json`` con la **misma huella** (config +
  hash de datos + commit + huellas aguas arriba). Si no, se borra lo parcial y se recalcula.
- El run de MLflow lleva ``idempotency_key``: un reintento sustituye al run anterior.
Reintentar una tarea o relanzar el DAG con el mismo run_key nunca duplica ni mezcla resultados.

CLI:  python -m src.stages <etapa> --config config/config.yaml --run-key demo [--model xgb]
"""
import argparse
import hashlib
import json
import os
import pickle
import re
import shutil
import sys
from datetime import datetime
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import joblib
import mlflow
import yaml

from src.monitoring import ComputeMonitor, info_hardware, tamano_modelo_mb
from src.provenance import git_info, hash_config, hash_datos, tags_trazabilidad
from src.tracking import log_compute, run_rastreado, serie_logger
from src.validation import validar_datos

ROOT = Path(__file__).resolve().parents[1]
MODELOS = ['xgb', 'lgbm', 'catb', 'logistic_regression', 'random_forest', 'ridge_classifier',
           'adaboost', 'gradient_boosting_sklearn', 'extra_trees']
ETAPAS = ['validate_data', 'prepare_data', 'hpo_model', 'select_hpo', 'benchmark',
          'get_best_model', 'backtesting', 'register_champion', 'generate_report']
VERSIONES = ['scikit-learn', 'xgboost', 'lightgbm', 'catboost', 'pandas', 'numpy', 'optuna', 'mlflow']


def versiones():
    """Versiones instaladas; en la imagen de Airflow solo hay mlflow-skinny, no mlflow."""
    out = {}
    for name in VERSIONES:
        for candidate in (name, name + '-skinny'):
            try:
                out[name] = version(candidate)
                break
            except PackageNotFoundError:
                continue
        else:
            out[name] = 'no-instalado'
    return out


# --------------------------------------------------------------------------
# Configuración y rutas
# --------------------------------------------------------------------------
def sanear(run_key):
    return re.sub(r'[^A-Za-z0-9_.-]+', '_', str(run_key)).strip('_') or 'manual'


def cargar_config(path='config/config.yaml', overrides=None):
    path = Path(path)
    if not path.is_absolute() and not path.exists():
        path = ROOT / path
    cfg = yaml.safe_load(path.read_text(encoding='utf-8'))
    # Rutas inyectables por entorno: en Docker los datos y salidas son volúmenes.
    if os.environ.get('DATA_INPUT_DIR'):
        cfg['input_dir'] = os.environ['DATA_INPUT_DIR']
    if os.environ.get('DATA_OUTPUT_DIR'):
        cfg['output_dir'] = os.environ['DATA_OUTPUT_DIR']
    for key in ('input_dir', 'output_dir'):
        if not Path(cfg[key]).is_absolute():
            cfg[key] = str((ROOT / cfg[key]).resolve())
    cfg.setdefault('update_root_readme', False)
    return _fusionar(cfg, overrides or {})


def _fusionar(base, extra):
    """Mezcla profunda: los overrides del DAG (p. ej. hpo.optuna.n_trials) no pisan el resto."""
    for key, value in extra.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _fusionar(base[key], value)
        else:
            base[key] = value
    return base


def run_key_por_defecto(cfg):
    """Clave de corrida determinista (D7): misma config + mismos datos + mismo commit => misma clave.

    Así, relanzar el DAG sin indicar ``run_key`` reutiliza la corrida existente (las etapas se saltan
    por huella) en lugar de crear un conjunto nuevo de runs. Si cambian datos, config o commit, la
    clave cambia y la corrida nueva no pisa a la anterior."""
    temporal = cfg['temporal']
    files = list(temporal['development_files']) + list(temporal['backtesting_files'])
    try:
        data = hash_datos(cfg['input_dir'], files, Path(cfg['output_dir']) / '.hash_cache.json')['data_hash']
    except OSError:
        data = 'datos-no-disponibles'  # validate_data fallará con un mensaje claro
    return 'auto-' + _huella(config=hash_config(cfg), data=data, git=git_info()['git_commit'])[:12]


def raiz_corrida(cfg, run_key):
    return Path(cfg['output_dir']) / 'runs' / sanear(run_key)


def dir_etapa(cfg, run_key, etapa, modelo=None):
    base = raiz_corrida(cfg, run_key) / etapa
    return base / 'models' / modelo if modelo else base


def _json_seguro(obj):
    import numpy as np
    if isinstance(obj, (np.floating,)):
        return None if obj != obj else float(obj)
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, Path):
        return str(obj)
    return str(obj)


def escribir_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, default=_json_seguro),
                          encoding='utf-8')


def leer_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def _huella(**parts):
    return hashlib.sha256(json.dumps(parts, sort_keys=True, default=str).encode()).hexdigest()


def _huella_etapa(cfg, run_key, etapa, modelo=None):
    """Huella guardada de una etapa ya completada (para encadenar la invalidación aguas abajo)."""
    marker = dir_etapa(cfg, run_key, etapa, modelo) / '_SUCCESS.json'
    return leer_json(marker)['fingerprint'] if marker.exists() else None


def hash_de_datos(cfg, run_key):
    """Hash de los CSV: lo calcula validate_data; el resto de etapas lo reutilizan."""
    fp = dir_etapa(cfg, run_key, 'validate_data') / 'data_fingerprint.json'
    if fp.exists():
        return leer_json(fp)['data_hash']
    temporal = cfg['temporal']
    files = list(temporal['development_files']) + list(temporal['backtesting_files'])
    return hash_datos(cfg['input_dir'], files, Path(cfg['output_dir']) / '.hash_cache.json')['data_hash']


# --------------------------------------------------------------------------
# Corredor idempotente + MLflow + cómputo
# --------------------------------------------------------------------------
def ejecutar_etapa(cfg, run_key, etapa, cuerpo, modelo=None, aguas_arriba=(), force=False):
    run_key = sanear(run_key)
    destino = dir_etapa(cfg, run_key, etapa, modelo)
    data_hash = hash_de_datos(cfg, run_key)
    huella = _huella(etapa=etapa, modelo=modelo, config=hash_config(cfg), data=data_hash,
                     git=git_info()['git_commit'], aguas_arriba=list(aguas_arriba))
    marker = destino / '_SUCCESS.json'
    if not force and marker.exists() and leer_json(marker).get('fingerprint') == huella \
            and (destino / 'result.json').exists():
        print(f'[{etapa}{"/" + modelo if modelo else ""}] SALTADA: ya completada con la misma huella.', flush=True)
        return {**leer_json(destino / 'result.json'), 'cached': True, 'fingerprint': huella}
    if destino.exists():
        shutil.rmtree(destino)  # salida parcial de un intento anterior
    destino.mkdir(parents=True)
    interval = float((cfg.get('compute_logging') or {}).get('interval_seconds', 2.0))
    with run_rastreado(cfg, etapa, run_key, modelo=modelo, data_hash=data_hash) as run:
        mlflow.set_tag('hardware', json.dumps(info_hardware()))
        mlflow.set_tag('fingerprint', huella)
        monitor = ComputeMonitor(f'{etapa}/{modelo or ""}', interval=interval,
                                 on_sample=serie_logger(run.info.run_id))
        with monitor:
            result = cuerpo(destino, run) or {}
        log_compute(monitor.summary)
        mlflow.set_tag('compute_mode', 'gpu' if monitor.summary.get('gpu_available') else 'cpu_only')
        result['compute'] = monitor.summary
        result['mlflow_run_id'] = run.info.run_id
        result['cached'] = False
        escribir_json(destino / 'result.json', result)
        mlflow.log_artifact(str(destino / 'result.json'), artifact_path='stage')
    escribir_json(marker, {'fingerprint': huella, 'finished_at': datetime.now().isoformat(),
                           'mlflow_run_id': run.info.run_id, 'stage': etapa, 'model': modelo})
    result['fingerprint'] = huella
    return result


def _cargar_dataset(cfg, run_key):
    path = dir_etapa(cfg, run_key, 'prepare_data') / 'dataset.joblib'
    if not path.exists():
        raise FileNotFoundError(f'Falta {path}: ejecutar prepare_data antes.')
    return joblib.load(path)


# --------------------------------------------------------------------------
# Etapa 1 — validación de datos (compuerta)
# --------------------------------------------------------------------------
def validate_data(cfg, run_key, force=False):
    run_key = sanear(run_key)
    destino = dir_etapa(cfg, run_key, 'validate_data')
    temporal = cfg['temporal']
    files = list(temporal['development_files']) + list(temporal['backtesting_files'])
    # El hash de datos se calcula aquí porque aún no existe data_fingerprint.json.
    cache = Path(cfg['output_dir']) / '.hash_cache.json'
    info_hash = hash_datos(cfg['input_dir'], [f for f in files if (Path(cfg['input_dir']) / f).is_file()], cache)
    huella = _huella(etapa='validate_data', config=hash_config(cfg), data=info_hash['data_hash'])
    marker = destino / '_SUCCESS.json'
    if not force and marker.exists() and leer_json(marker).get('fingerprint') == huella:
        print('[validate_data] SALTADA: mismos datos y config ya validados.', flush=True)
        return {**leer_json(destino / 'result.json'), 'cached': True, 'fingerprint': huella}
    if destino.exists():
        shutil.rmtree(destino)
    destino.mkdir(parents=True)
    escribir_json(destino / 'data_fingerprint.json', info_hash)
    with run_rastreado(cfg, 'validate_data', run_key, data_hash=info_hash['data_hash']) as run:
        mlflow.set_tag('fingerprint', huella)
        monitor = ComputeMonitor('validate_data', interval=2.0, on_sample=serie_logger(run.info.run_id))
        try:
            with monitor:
                report = validar_datos(cfg, destino / 'validation_report.json')
        except Exception:
            # Que el reporte de errores quede en MLflow aunque la compuerta falle.
            if (destino / 'validation_report.json').exists():
                mlflow.log_artifact(str(destino / 'validation_report.json'), artifact_path='validation')
            mlflow.set_tag('validation_ok', 'false')
            raise
        log_compute(monitor.summary)
        mlflow.set_tag('compute_mode', 'gpu' if monitor.summary.get('gpu_available') else 'cpu_only')
        mlflow.set_tag('validation_ok', 'true')
        mlflow.log_artifact(str(destino / 'validation_report.json'), artifact_path='validation')
        mlflow.log_artifact(str(destino / 'data_fingerprint.json'), artifact_path='validation')
        mlflow.log_metrics({'validation.n_files': len(report['files']),
                            'validation.n_warnings': len(report['warnings']),
                            'validation.rows_total': sum(f['rows'] for f in report['files'])})
        result = {'ok': True, 'data_hash': info_hash['data_hash'], 'warnings': report['warnings'],
                  'rows': {f['file']: f['rows'] for f in report['files']}, 'compute': monitor.summary,
                  'mlflow_run_id': run.info.run_id, 'cached': False}
        escribir_json(destino / 'result.json', result)
    escribir_json(marker, {'fingerprint': huella, 'finished_at': datetime.now().isoformat(),
                           'mlflow_run_id': run.info.run_id, 'stage': 'validate_data'})
    result['fingerprint'] = huella
    return result


# --------------------------------------------------------------------------
# Etapa 2 — muestreo + split temporal (meses 1–6 únicamente)
# --------------------------------------------------------------------------
def prepare_data(cfg, run_key, force=False):
    from src.preprocessing import cargar_desarrollo_temporal

    def cuerpo(destino, run):
        X_train, X_val, y_train, y_val, manifest = cargar_desarrollo_temporal(cfg)
        joblib.dump((X_train, y_train, X_val, y_val, manifest), destino / 'dataset.joblib')
        escribir_json(destino / 'manifest.json', manifest)
        mlflow.log_artifact(str(destino / 'manifest.json'), artifact_path='prepare')
        mlflow.log_metrics({'rows_train': len(X_train), 'rows_validation': len(X_val),
                            'n_features': X_train.shape[1],
                            'positive_rate_train': float(y_train.mean()),
                            'positive_rate_validation': float(y_val.mean()),
                            'dataset_size_mb': tamano_modelo_mb(destino / 'dataset.joblib')})
        return {'rows_train': len(X_train), 'rows_validation': len(X_val), 'n_features': X_train.shape[1],
                'dataset_path': str(destino / 'dataset.joblib')}
    return ejecutar_etapa(cfg, run_key, 'prepare_data', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'validate_data')])


def _guardar_roc(model, X_val, y_val, nombre, path):
    """Curva ROC del modelo sobre la validación (meses 1–6) como PNG; devuelve la ruta."""
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_auc_score, roc_curve
    from src.evaluation import obtener_scores
    scores = obtener_scores(model, X_val)
    fpr, tpr, _ = roc_curve(y_val, scores)
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.plot(fpr, tpr, label=f'AUC = {roc_auc_score(y_val, scores):.4f}')
    ax.plot([0, 1], [0, 1], 'k:', label='Azar')
    ax.set_xlabel('FPR'); ax.set_ylabel('TPR'); ax.set_title(f'ROC validación — {nombre}')
    ax.legend(loc='lower right'); fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return str(path)


# --------------------------------------------------------------------------
# Etapa 3 — HPO de UN modelo (una tarea del DAG por modelo)
# --------------------------------------------------------------------------
def hpo_model(cfg, run_key, modelo, force=False):
    from src.hpo import definir_modelos_hpo, hpo_un_modelo
    from src.registry import guardar_metadata, guardar_modelo
    if modelo not in MODELOS:
        raise ValueError(f'Modelo desconocido: {modelo}. Opciones: {MODELOS}')

    def cuerpo(destino, run):
        X_train, y_train, X_val, y_val, manifest = _cargar_dataset(cfg, run_key)
        ratio = float((y_train == 0).sum() / (y_train == 1).sum())
        estimator = definir_modelos_hpo(cfg.get('random_seed', 42), ratio)[modelo]
        on_trial = lambda i, v: mlflow.log_metric('hpo.trial_auc_cv', v, step=i)
        model, perf, hpo, table = hpo_un_modelo(modelo, estimator, X_train, y_train, X_val, y_val, cfg, on_trial)
        pkl = guardar_modelo(model, modelo, str(destino))
        versions = versiones()
        meta_path = guardar_metadata(modelo, perf, model.named_steps['model'].get_params(), versions, str(destino))
        metadata = leer_json(meta_path)
        metadata.update(hpo=hpo, hardware='CPU', data_split=manifest)
        escribir_json(meta_path, metadata)
        csv = destino / f'{modelo}_hpo_results.csv'
        table.to_csv(csv, index=False)
        size = tamano_modelo_mb(pkl)
        roc_png = _guardar_roc(model, X_val, y_val, modelo, destino / f'{modelo}_roc.png')
        mlflow.log_artifact(pkl, artifact_path='model')       # modelo serializado
        mlflow.log_artifact(roc_png, artifact_path='hpo')     # curva ROC (validación)
        mlflow.log_params({f'best.{k}': v for k, v in hpo['best_parameters'].items()})
        mlflow.log_metrics({f'perf.{k}': float(v) for k, v in perf.items() if isinstance(v, (int, float)) and v == v})
        mlflow.log_metrics({'model_size_mb': size, 'hpo.n_trials': hpo['n_trials'],
                            'hpo.elapsed_seconds': hpo['elapsed_seconds']})
        mlflow.log_artifact(meta_path, artifact_path='hpo')
        mlflow.log_artifact(str(csv), artifact_path='hpo')
        return {'model': modelo, 'performance': perf, 'hpo': hpo, 'model_path': pkl,
                'metadata_path': meta_path, 'model_size_mb': size}
    return ejecutar_etapa(cfg, run_key, 'hpo', cuerpo, modelo=modelo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'prepare_data')])


# --------------------------------------------------------------------------
# Etapa 4 — consolidación HPO (formato results_summary.json compatible con paralelismo)
# --------------------------------------------------------------------------
def select_hpo(cfg, run_key, force=False):
    from src.training import GetBestModel

    def cuerpo(destino, run):
        manifest = leer_json(dir_etapa(cfg, run_key, 'prepare_data') / 'manifest.json')
        models = {}
        for m in MODELOS:
            res_path = dir_etapa(cfg, run_key, 'hpo', m) / 'result.json'
            if not res_path.exists():
                raise FileNotFoundError(f'Falta el HPO de {m}: {res_path}')
            res = leer_json(res_path)
            models[m] = {'model': None, 'performance': res['performance'], 'hpo': res['hpo']}
        champion, _, perf = GetBestModel(models, cfg)
        summary = {'campeon': champion, 'config': cfg, 'data_split': manifest, 'stage': 'HPO (DAG)',
                   'models': {k: {'performance': v['performance'], 'hpo': v['hpo']} for k, v in models.items()}}
        escribir_json(destino / 'results_summary.json', summary)
        mlflow.log_artifact(str(destino / 'results_summary.json'), artifact_path='hpo')
        mlflow.set_tag('hpo_champion', str(champion))
        primary = (cfg.get('business_metric') or {}).get('primary', 'capture_rate_top_k')
        mlflow.log_metrics({f'{k}.{primary}': float(v['performance'][primary]) for k, v in models.items()
                            if v['performance'].get(primary) is not None})
        return {'campeon_hpo': champion, 'summary_path': str(destino / 'results_summary.json')}
    ups = [_huella_etapa(cfg, run_key, 'hpo', m) for m in MODELOS]
    return ejecutar_etapa(cfg, run_key, 'select_hpo', cuerpo, force=force, aguas_arriba=ups)


# --------------------------------------------------------------------------
# Etapa 5 — benchmark secuencial vs paralelo (9 modelos, mismos HP)
# --------------------------------------------------------------------------
def benchmark(cfg, run_key, force=False):
    from src.parallel import run_parallel

    def cuerpo(destino, run):
        X_train, y_train, X_val, y_val, manifest = _cargar_dataset(cfg, run_key)
        local = {**cfg, 'output_dir': str(destino)}
        out, summary = run_parallel(X_train, y_train, X_val, y_val, local, manifest,
                                    source_dir=dir_etapa(cfg, run_key, 'select_hpo'))
        sizes = {m: tamano_modelo_mb(Path(out) / f'{m}_model.pkl') for m in MODELOS}
        mlflow.log_metrics({'T_sequential_seconds': summary['T_sequential_seconds'],
                            'T_parallel_seconds': summary['T_parallel_seconds'],
                            'speedup': summary['speedup'], 'workers': summary['workers']})
        for m, d in summary['per_model'].items():
            mlflow.log_metrics({f'fit_seq_s.{m}': d['sequential']['fit_seconds'],
                                f'fit_par_s.{m}': d['parallel']['fit_seconds'],
                                f'model_size_mb.{m}': sizes[m]})
        mlflow.set_tag('gpu_available', str(summary['hardware']['available']).lower())
        mlflow.log_artifact(str(Path(out) / 'results_summary.json'), artifact_path='benchmark')
        mlflow.log_artifact(str(Path(out) / 'README.md'), artifact_path='benchmark')
        return {'parallel_dir': str(out), 'campeon_paralelo': summary['campeon'], 'speedup': summary['speedup'],
                'T_sequential_seconds': summary['T_sequential_seconds'],
                'T_parallel_seconds': summary['T_parallel_seconds'], 'model_size_mb': sizes}
    return ejecutar_etapa(cfg, run_key, 'benchmark', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'select_hpo')])


# --------------------------------------------------------------------------
# Etapa 6 — GetBestModel() sobre los modelos del benchmark (solo validación, nunca meses futuros)
# --------------------------------------------------------------------------
def get_best_model_stage(cfg, run_key, force=False):
    from src.training import GetBestModel

    def cuerpo(destino, run):
        bench = leer_json(dir_etapa(cfg, run_key, 'benchmark') / 'result.json')
        parallel_dir = Path(bench['parallel_dir'])
        summary = leer_json(parallel_dir / 'results_summary.json')
        models = {k: {'model': None, 'performance': v['performance']} for k, v in summary['models'].items()}
        name, _, perf = GetBestModel(models, cfg)
        if name is None:
            raise RuntimeError('Ningún modelo cumple los criterios de GetBestModel (decay / AUC mínimo). '
                               'Revisar datos o relajar max_decay_percent / min_auc_test.')
        primary = (cfg.get('business_metric') or {}).get('primary', 'capture_rate_top_k')
        champ = {'champion': name, 'performance': perf, 'primary_metric': primary,
                 'primary_value': perf.get(primary), 'parallel_dir': str(parallel_dir),
                 'model_path': str(parallel_dir / f'{name}_model.pkl'),
                 'metadata_path': str(parallel_dir / f'{name}_metadata.json'),
                 'consistent_with_benchmark': name == summary.get('campeon'),
                 'criteria': {'primary_metric': primary, 'tie_tolerance': (cfg.get('business_metric') or {}).get('tie_tolerance'),
                              'max_decay_percent': cfg.get('max_decay_percent'), 'min_auc_test': cfg.get('min_auc_test'),
                              'decay_type': (cfg.get('decay') or {}).get('type', 'relative'),
                              'candidates': {k: {'metric': v['performance'].get(primary), 'auc_test': v['performance'].get('auc_test'),
                                                 'decay_percent': v['performance'].get('decay_percent'),
                                                 'training_time_segs': v['performance'].get('training_time_segs')}
                                             for k, v in models.items()}}}
        escribir_json(destino / 'champion.json', champ)
        mlflow.set_tag('champion', name)
        mlflow.log_dict(champ['criteria'], 'selection/criteria_getbestmodel.json')  # criterio aplicado en esta corrida
        mlflow.log_metrics({f'champion.{k}': float(v) for k, v in perf.items()
                            if isinstance(v, (int, float)) and v == v})
        mlflow.log_metric('champion.model_size_mb', tamano_modelo_mb(champ['model_path']))
        mlflow.log_artifact(str(destino / 'champion.json'), artifact_path='selection')
        return champ
    return ejecutar_etapa(cfg, run_key, 'get_best_model', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'benchmark')])


# --------------------------------------------------------------------------
# Etapa 7 — backtesting con el campeón fijo (meses 7–10; no influye en la selección)
# --------------------------------------------------------------------------
def backtesting(cfg, run_key, force=False):
    from src.backtesting import run_backtesting

    def cuerpo(destino, run):
        champ = leer_json(dir_etapa(cfg, run_key, 'get_best_model') / 'champion.json')
        if not champ['consistent_with_benchmark']:
            raise RuntimeError('El campeón de get_best_model no coincide con el del benchmark: no se evalúa.')
        local = {**cfg, 'output_dir': str(destino)}
        out, results = run_backtesting(local, champ['parallel_dir'])
        mlflow.set_tag('champion', results['champion'])
        mlflow.log_metrics({'backtest.mean_auc_valid_waves': results['mean_auc_valid_waves'] or 0.0,
                            'backtest.valid_waves': results['valid_waves'],
                            'backtest.reference_auc': results['reference_auc']})
        mlflow.log_metric('backtest.drift_alerts', float(results.get('drift_alerts', 0)))
        mlflow.set_tag('drift_alert', str(bool(results.get('drift_alerts'))).lower())
        for w in results['waves']:
            for k in ('auc', 'decay_percent', 'capture_rate_top_k', 'lift_top_k'):
                if w.get(k) is not None:
                    mlflow.log_metric(f'backtest.{k}', float(w[k]), step=w['wave'])
        for f in ('backtesting_results.json', 'backtesting_results.csv', 'auc_por_ola.png', 'README.md'):
            mlflow.log_artifact(str(Path(out) / f), artifact_path='backtesting')
        return {'backtest_dir': str(out), 'mean_auc': results['mean_auc_valid_waves'],
                'valid_waves': results['valid_waves'], 'status': results['status']}
    return ejecutar_etapa(cfg, run_key, 'backtesting', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'get_best_model')])


# --------------------------------------------------------------------------
# Etapa 8 — registro y promoción del campeón en el Model Registry de MLflow (punto extra)
# --------------------------------------------------------------------------
def register_champion(cfg, run_key, force=False):
    from mlflow.models import infer_signature
    from mlflow.tracking import MlflowClient

    reg = cfg.get('registry') or {}
    model_name = reg.get('model_name', 'automl-venta-financiera')
    alias = reg.get('alias', 'champion')
    primary = (cfg.get('business_metric') or {}).get('primary', 'capture_rate_top_k')
    challenger_alias = reg.get('challenger_alias', 'challenger')
    min_margin = float(reg.get('min_margin', 0.0))

    def cuerpo(destino, run):
        champ = leer_json(dir_etapa(cfg, run_key, 'get_best_model') / 'champion.json')
        with open(champ['model_path'], 'rb') as f:
            model = pickle.load(f)
        X_train, y_train, X_val, y_val, manifest = _cargar_dataset(cfg, run_key)
        head = X_val.head(5)
        signature = infer_signature(head, model.predict(head))
        value = champ['performance'].get(primary)
        # Reutilizar una versión equivalente evita crear duplicados en reintentos,
        # incluso si el proceso falló después de registrar el modelo.
        client = MlflowClient()
        version_key = hashlib.sha256(json.dumps({
            'run_key': sanear(run_key),
            'champion': champ['champion'],
            'data_hash': hash_de_datos(cfg, run_key),
            'config_hash': hash_config(cfg),
            'git_commit': git_info()['git_commit'],
        }, sort_keys=True).encode('utf-8')).hexdigest()
        existing = None
        try:
            for candidate in client.search_model_versions(f"name='{model_name}'"):
                if candidate.tags.get('version_key') == version_key:
                    existing = candidate
                    break
        except Exception as exc:
            if 'RESOURCE_DOES_NOT_EXIST' not in str(exc) and 'not found' not in str(exc).lower():
                raise
        if existing is None:
            # cloudpickle permite serializar pipelines XGBoost/CatBoost.
            info = mlflow.sklearn.log_model(
                model, name='model', signature=signature,
                serialization_format='cloudpickle',
                registered_model_name=model_name)
            version_num = str(info.registered_model_version)
        else:
            version_num = str(existing.version)
            mlflow.set_tag('registry.reused_version', 'true')
        tags = {'champion': champ['champion'], primary: str(value), 'auc_test': str(champ['performance']['auc_test']),
                'run_key': sanear(run_key), 'data_hash': hash_de_datos(cfg, run_key),
                'git_commit': git_info()['git_commit'], 'source_run_id': run.info.run_id,
                'version_key': version_key, 'config_hash': hash_config(cfg)}
        for k, v in tags.items():
            client.set_model_version_tag(model_name, version_num, k, v)
        promoted, reason, current_value, previous_version = True, 'no había campeón previo', None, None
        try:
            current = client.get_model_version_by_alias(model_name, alias)
            previous_version = str(current.version)
            current_value = float(current.tags.get(primary, 'nan'))
            if previous_version == version_num:
                reason = 'esta versión ya es el campeón vigente'
            elif value is None or current_value != current_value:
                promoted, reason = False, 'no comparable con el campeón vigente'
            elif value - current_value >= min_margin:
                reason = (f'{primary} {value:.4f} >= vigente {current_value:.4f} + margen {min_margin}')
            else:
                promoted, reason = False, (f'{primary} {value:.4f} < vigente {current_value:.4f} + margen {min_margin}')
        except Exception:
            pass  # sin alias previo: primera promoción
        if promoted:
            client.set_registered_model_alias(model_name, alias, version_num)
        else:
            client.set_registered_model_alias(model_name, challenger_alias, version_num)
        client.set_model_version_tag(model_name, version_num, 'promotion_decision',
                                     ('champion: ' if promoted else 'challenger: ') + reason)
        mlflow.set_tag('promotion_reason', reason)
        mlflow.set_tag('previous_champion_version', str(previous_version))
        mlflow.set_tag('promoted', str(promoted).lower())
        mlflow.log_metric('registry.model_version', float(version_num))
        result = {'registered_model': model_name, 'version': version_num, 'alias': alias, 'promoted': promoted,
                  'reason': reason, 'previous_champion_version': previous_version,
                  'min_margin': min_margin, 'current_champion_value': current_value, 'new_value': value,
                  'champion': champ['champion']}
        escribir_json(destino / 'promotion.json', result)
        mlflow.log_artifact(str(destino / 'promotion.json'), artifact_path='registry')
        print(f'[registry] {model_name} v{version_num} | promovido={promoted} | {reason}', flush=True)
        return result
    # force=True: el registro es una acción sobre un servidor externo; se rehace con la misma huella.
    return ejecutar_etapa(cfg, run_key, 'register_champion', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'get_best_model'),
                                        _huella_etapa(cfg, run_key, 'backtesting')])


# --------------------------------------------------------------------------
# Etapa 9 — reporte final: results_summary.json, compute_logs.json y tablas para el README
# --------------------------------------------------------------------------
def generate_report(cfg, run_key, force=False):
    """Consolida la corrida: imprime el resumen y escribe ``results_summary.json``,
    ``compute_logs.json`` y ``report.md`` (tablas listas para el README) en el directorio de la corrida
    (``runs/<run_key>/``) y en la carpeta de la etapa; también los registra en MLflow."""
    def cuerpo(destino, run):
        primary = (cfg.get('business_metric') or {}).get('primary', 'capture_rate_top_k')
        champ = leer_json(dir_etapa(cfg, run_key, 'get_best_model') / 'champion.json')
        bench = leer_json(dir_etapa(cfg, run_key, 'benchmark') / 'result.json')
        summary = leer_json(Path(bench['parallel_dir']) / 'results_summary.json')
        bt_dir = Path(leer_json(dir_etapa(cfg, run_key, 'backtesting') / 'result.json')['backtest_dir'])
        bt = leer_json(bt_dir / 'backtesting_results.json')
        promo = leer_json(dir_etapa(cfg, run_key, 'register_champion') / 'promotion.json')

        # --- logs de cómputo: por tarea del DAG y por modelo ---
        tareas = {}
        for etapa in ['validate_data', 'prepare_data', 'select_hpo', 'benchmark', 'get_best_model',
                      'backtesting', 'register_champion']:
            res = leer_json(dir_etapa(cfg, run_key, etapa) / 'result.json')
            tareas[etapa] = res.get('compute')
        por_modelo = {}
        for m in MODELOS:
            res = leer_json(dir_etapa(cfg, run_key, 'hpo', m) / 'result.json')
            tareas[f'hpo/{m}'] = res.get('compute')
            fits = summary.get('per_model', {}).get(m, {})
            por_modelo[m] = {'hpo_compute': res.get('compute'),
                             'hpo_elapsed_seconds': res['hpo']['elapsed_seconds'],
                             'refit_seconds': res['performance'].get('training_time_segs'),
                             'fit_sequential_seconds': (fits.get('sequential') or {}).get('fit_seconds'),
                             'fit_parallel_seconds': (fits.get('parallel') or {}).get('fit_seconds'),
                             'model_size_mb': res.get('model_size_mb')}
        hw = info_hardware()
        compute_logs = {'run_key': sanear(run_key), 'generated_at': datetime.now().isoformat(),
                        'hardware': hw, 'compute_mode': 'gpu' if hw['gpu_available'] else 'cpu_only',
                        'note': ('Corrida solo en CPU: no hay GPU disponible.' if not hw['gpu_available']
                                 else 'GPU disponible (ver gpu_* en cada tarea).'),
                        'tasks': tareas, 'models': por_modelo,
                        'benchmark': {k: bench.get(k) for k in ('T_sequential_seconds', 'T_parallel_seconds', 'speedup')}}
        resultados = {'run_key': sanear(run_key), 'generated_at': compute_logs['generated_at'],
                      'champion': champ['champion'], 'primary_metric': primary,
                      'selection_criteria': champ.get('criteria'),
                      'models': {m: {'performance': summary['models'][m]['performance'],
                                     'hpo': leer_json(dir_etapa(cfg, run_key, 'hpo', m) / 'result.json')['hpo'],
                                     'model_size_mb': por_modelo[m]['model_size_mb']} for m in MODELOS},
                      'backtesting': {k: bt.get(k) for k in ('champion', 'reference_auc', 'mean_auc_valid_waves',
                                                              'valid_waves', 'drift_alerts', 'status', 'waves')},
                      'registry': promo,
                      'traceability': tags_trazabilidad(cfg, data_hash=hash_de_datos(cfg, run_key), run_key=sanear(run_key))}
        # --- tablas para el README ---
        f = lambda v, n=4: '—' if v is None else (f'{v:.{n}f}' if isinstance(v, (int, float)) else str(v))
        L = [f'## Corrida `{sanear(run_key)}` — campeón: **{champ["champion"]}** ({primary} = {f(champ.get("primary_value"))})', '',
             f'### Modelos (validación meses 1–6)', '',
             f'| Modelo | {primary} | Lift top-k | AUC train | AUC test | Decay % | KS | Fit s | Tamaño MB |',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
        for m in MODELOS:
            pf = summary['models'][m]['performance']
            L.append(f'| {m} | {f(pf.get(primary))} | {f(pf.get("lift_top_k"))} | {f(pf.get("auc_train"))} | {f(pf.get("auc_test"))} '
                     f'| {f(pf.get("decay_percent"), 2)} | {f(pf.get("ks"))} | {f(pf.get("training_time_segs"), 1)} | {f(por_modelo[m]["model_size_mb"])} |')
        L += ['', '### Backtesting (campeón fijo, sin reentrenar)', '',
              f'| Ola | Archivo | AUC | Decay % | {primary} | Lift | Alerta drift |', '|---|---|---:|---:|---:|---:|:---:|']
        for w in bt['waves']:
            L.append(f'| T+{w["wave"]} | {w["file"]} | {f(w.get("auc"))} | {f(w.get("decay_percent"), 2)} | '
                     f'{f(w.get("capture_rate_top_k"))} | {f(w.get("lift_top_k"))} | {"sí" if w.get("drift_alert") else "no"} |')
        L += ['', f'### Logs de cómputo por modelo (modo: {compute_logs["compute_mode"]}, {hw["cpu_logical"]} CPU lógicas, {hw["ram_total_mb"]:.0f} MB RAM)', '',
              '| Modelo | HPO s | CPU % prom | CPU % máx | RAM MB prom | RAM MB máx | Procesos máx | GPU | Tamaño MB |',
              '|---|---:|---:|---:|---:|---:|---:|:---:|---:|']
        for m in MODELOS:
            c = por_modelo[m]['hpo_compute'] or {}
            L.append(f'| {m} | {f(por_modelo[m]["hpo_elapsed_seconds"], 1)} | {f(c.get("cpu_percent_avg"), 1)} | {f(c.get("cpu_percent_max"), 1)} '
                     f'| {f(c.get("ram_rss_mb_avg"), 0)} | {f(c.get("ram_rss_mb_max"), 0)} | {f(c.get("processes_max"), 0)} '
                     f'| {"sí" if c.get("gpu_available") else "solo CPU"} | {f(por_modelo[m]["model_size_mb"])} |')
        L += ['', f'Benchmark: T secuencial {f(bench.get("T_sequential_seconds"), 1)} s | T paralelo {f(bench.get("T_parallel_seconds"), 1)} s | '
                  f'speed-up {f(bench.get("speedup"), 2)}.',
              f'Registro: v{promo["version"]} — promovido a `{promo["alias"]}`: {promo["promoted"]} ({promo["reason"]}).']
        informe = '\n'.join(L)
        print('\n' + informe, flush=True)
        raiz = raiz_corrida(cfg, run_key)
        for carpeta in (destino, raiz):
            escribir_json(carpeta / 'results_summary.json', resultados)
            escribir_json(carpeta / 'compute_logs.json', compute_logs)
            (carpeta / 'report.md').write_text(informe, encoding='utf-8')
        for name in ('results_summary.json', 'compute_logs.json', 'report.md'):
            mlflow.log_artifact(str(destino / name), artifact_path='report')
        mlflow.set_tag('champion', champ['champion'])
        return {'report_dir': str(raiz), 'champion': champ['champion']}
    return ejecutar_etapa(cfg, run_key, 'generate_report', cuerpo, force=force,
                          aguas_arriba=[_huella_etapa(cfg, run_key, 'register_champion'),
                                        _huella_etapa(cfg, run_key, 'backtesting')])


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------
def ejecutar(etapa, cfg, run_key, modelo=None, force=False):
    if etapa == 'validate_data':
        return validate_data(cfg, run_key, force)
    if etapa == 'prepare_data':
        return prepare_data(cfg, run_key, force)
    if etapa == 'hpo_model':
        return hpo_model(cfg, run_key, modelo, force)
    if etapa == 'select_hpo':
        return select_hpo(cfg, run_key, force)
    if etapa == 'benchmark':
        return benchmark(cfg, run_key, force)
    if etapa == 'get_best_model':
        return get_best_model_stage(cfg, run_key, force)
    if etapa == 'backtesting':
        return backtesting(cfg, run_key, force)
    if etapa == 'register_champion':
        return register_champion(cfg, run_key, force)
    if etapa == 'generate_report':
        return generate_report(cfg, run_key, force)
    raise ValueError(f'Etapa desconocida: {etapa}')


def main(argv=None):
    parser = argparse.ArgumentParser(description='Ejecuta una etapa idempotente del pipeline.')
    parser.add_argument('etapa', choices=ETAPAS + ['all'])
    parser.add_argument('--config', default='config/config.yaml')
    parser.add_argument('--run-key', default='manual')
    parser.add_argument('--model', default=None)
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args(argv)
    cfg = cargar_config(args.config)
    if args.etapa == 'all':  # ejecución local sin Airflow (útil para depurar y para los tests)
        for etapa in ETAPAS:
            if etapa == 'hpo_model':
                for m in MODELOS:
                    ejecutar(etapa, cfg, args.run_key, m, args.force)
            else:
                ejecutar(etapa, cfg, args.run_key, None, args.force)
        return
    print(json.dumps(ejecutar(args.etapa, cfg, args.run_key, args.model, args.force),
                     indent=2, ensure_ascii=False, default=_json_seguro))


if __name__ == '__main__':
    sys.exit(main())
