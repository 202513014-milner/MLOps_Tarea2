# Decisiones de diseño (D1–D9)

> **Estado:** propuesta técnica con justificación, implementada y probada con datos sintéticos.
> Cada decisión debe ser revisada y asumida por el grupo antes de la sustentación: ahí se evalúa
> que cada integrante pueda **defender el porqué**, no solo el qué. Las cifras con datos reales
> (tiempos, speed-up, métricas) se anotan en la sección final, tras ejecutar el DAG con los 10 CSV.

Cada decisión indica: qué se decidió, qué alternativas se descartaron y por qué, dónde vive en el
código y qué limitaciones asumimos.

---

## D1. Tipo de decay

**Decisión.** Decay **relativo en porcentaje**: `100 · (AUC_ref − AUC_obs) / AUC_ref`. Un valor negativo
indica mejora. Se usa en dos sitios:

| Uso | Referencia | Observado | Para qué |
|---|---|---|---|
| Filtro de selección (GetBestModel) | AUC train | AUC validación (30 % de meses 1–6) | Descartar sobreajuste (`max_decay_percent = 10`) |
| Backtesting | AUC validación del campeón | AUC de cada mes futuro T+1…T+4 | Medir degradación temporal |

**Alternativas.** (a) Decay absoluto en puntos de AUC; (b) decay respecto a un baseline (p. ej. AUC 0.5).

**Por qué.** El relativo es comparable entre modelos con distinta escala de AUC (una caída de 0.05 pesa
distinto sobre 0.65 que sobre 0.90) y es la definición ya usada en la P1/P2, por lo que los umbrales
(10 %) y las tablas siguen siendo comparables. El absoluto se conserva como opción
(`decay.type: absolute`, helper `src/ops_metrics.py::calcular_decay`) para análisis de sensibilidad.

**Límite.** El decay train→validación mide sobreajuste, no deriva temporal; esta última solo la mide el
backtesting (origen fijo, sin reentrenar).

---

## D2. Cómputo secuencial o paralelo

**Decisión.** **Paralelo en producción, secuencial solo como línea base del benchmark.**
- HPO: las 9 tareas del DAG corren en paralelo, limitadas por el pool de Airflow `automl_compute`
  (`AUTOML_POOL_SLOTS`, por defecto 2) para no saturar CPU/RAM.
- Benchmark (`src/parallel.py`): entrena los 9 modelos con los mismos hiperparámetros primero en
  secuencial y luego en paralelo (joblib/loky), midiendo `T_secuencial`, `T_paralelo` y speed-up.
- Cada estimador usa 1 hilo (`n_jobs=1`, BLAS limitado con threadpoolctl) para evitar sobresuscripción.
- Si hay GPU, XGBoost/CatBoost/LightGBM la usan solo tras un fit real de verificación; un lock evita dos
  fits simultáneos en la GPU.

**Alternativas.** Todo secuencial (simple, reproducible, lento); paralelismo dentro de cada modelo
(`n_jobs=-1`): compite con las otras tareas por los mismos núcleos.

**Por qué.** Los nueve modelos son independientes (paralelismo trivial). Paralelizar por modelo escala con
núcleos sin depender de que cada librería paralelice bien internamente. El pool convierte la
concurrencia en un parámetro operativo.

**Límites.** Con pocos núcleos o RAM el speed-up puede ser < 1 (el benchmark lo reporta tal cual).
Cada tarea de HPO carga el dataset de muestra en memoria: `pool slots × tamaño del dataset` debe caber en RAM.

---

## D3. Granularidad del DAG

**Decisión.** Ocho etapas, con **una tarea por modelo** en HPO (14 tareas):

```
validate_data → prepare_data → hpo.<9 modelos> → select_hpo → benchmark
                                                                  ↓
                       register_champion ← backtesting ← get_best_model
```

**Alternativas.** (a) Una sola tarea “entrenar todo”: sin reintento parcial ni visibilidad;
(b) una tarea por modelo y por etapa (también benchmark/backtest por modelo): más overhead y rompe
la comparación secuencial vs paralelo, que debe medirse en un mismo proceso.

**Por qué.** La unidad de reintento/idempotencia debe coincidir con la unidad de fallo: si CatBoost falla
a la 3.ª hora, solo se repite CatBoost. Separar validación, preparación, selección, backtesting y registro
hace explícito qué datos entran a cada decisión (los meses 7–10 solo aparecen en `backtesting`).

**Límite.** Cada tarea paga unos segundos de arranque y relee el dataset de muestra (`dataset.joblib`).

---

## D4. Métrica de negocio

**Decisión.** **Captura de ventas en el top 10 % de scores** (`capture_rate_top_k`, `top_fraction = 0.10`):
de todas las ventas reales, qué fracción cae entre el 10 % de clientes con mayor score. Se reportan
también `lift_top_k` y `precision_top_k`.

**Alternativas.** AUC (no refleja la capacidad limitada de contacto); F1 (depende de un umbral que el
negocio no fijó); ingresos esperados (requiere montos/márgenes que no están en los datos).

**Por qué.** El caso es venta financiera con contact center de capacidad limitada: lo que importa es cuántas
ventas se capturan llamando solo a una fracción de la cartera. Es interpretable para negocio
(“con el 10 % de llamadas capturamos X % de ventas”) y se calcula con scores no calibrados (también Ridge).

**Límite.** `k = 10 %` es un supuesto de capacidad operativa; se cambia en `business_metric.top_fraction`.
Con pocas ventas en validación la métrica tiene ruido → ver tolerancia de empate en D8.

---

## D5. Estrategia de HPO / AutoML

**Decisión.** **Optuna (TPE, búsqueda bayesiana)** por modelo: 15 trials, CV estratificada de 3 folds,
máximo 600 s por modelo, semilla fija. Los espacios de búsqueda están en `hpo.optuna.spaces`
(enteros/flotantes, escala log para tasas de aprendizaje y regularización). Se mantiene el modelo
`GridSearchCV` de la P2 como `hpo.strategy: grid` para comparar.

**Alternativas.** GridSearchCV (explota con más hiperparámetros); H2O/FLAML (traen su propio
preprocesamiento y selección de modelos, lo que rompería el pipeline P1/P2, la comparación entre los
nueve modelos y los pipelines serializados que usa el backtesting).

**Por qué.** TPE explora espacios continuos con presupuesto fijo; permite acotar tiempo (`timeout`) y
trials, algo que una rejilla no ofrece. El presupuesto por modelo es explícito y configurable
(`n_trials` también como parámetro del DAG).

**Límites.** El AUC CV elegido es optimista (no es CV anidada). Con `timeout` activo el número de trials
depende de la velocidad de la máquina: la corrida es reproducible solo si no se corta por tiempo.
Con 15 trials la búsqueda es modesta; subir `n_trials` mejora el resultado a costa de tiempo.

---

## D6. Gestor de experimentos

**Decisión.** **MLflow** (tracking + Model Registry), servidor propio en Docker con SQLite y artefactos
servidos por el servidor (`--serve-artifacts`); los clientes solo usan HTTP.

**Alternativas.** Neptune/W&B (SaaS externo, requiere cuenta/token y sube datos fuera); DVC (versiona
datos, no gestiona runs ni registro de modelos).

**Por qué.** Open source, autoalojado (sin credenciales ni datos fuera de la máquina), incluye Model Registry
con alias (necesario para promover al campeón), integración directa con sklearn/XGBoost y UI para comparar runs.

**Trazabilidad (cada run):**

| Qué | Dónde queda |
|---|---|
| Commit de git (+ rama y si el árbol estaba sucio) | tags `git_commit`, `git_branch`, `git_dirty` |
| Hash de los datos (SHA-256 de los 10 CSV, combinado) | tag `data_hash` + artefacto `data_fingerprint.json` |
| Imagen Docker (tag e id) | tags `docker_image`, `docker_image_id` |
| Configuración | artefacto `config/config_efectiva.yaml`, tag `config_hash`, params clave |
| Ejecución del DAG | tags `airflow_dag_id`, `airflow_run_id`, `airflow_task_id`, `airflow_try_number`, `run_key` |

**Límite.** SQLite sirve para un usuario/equipo pequeño; para varios escritores concurrentes se cambia
`--backend-store-uri` a PostgreSQL y los artefactos a S3/MinIO sin tocar el código.

---

## D7. Idempotencia

**Decisión.** Cada ejecución del DAG tiene una **`run_key`** (por defecto el `run_id` de Airflow, o un valor
manual para retomar una corrida). Cada tarea:
1. escribe solo en `runs/<run_key>/<etapa>[/models/<m>]/`;
2. calcula una **huella** = etapa + modelo + hash de config + hash de datos + commit + huellas de las etapas
   anteriores; si existe `_SUCCESS.json` con esa huella, **se salta**;
3. si no, borra la salida parcial, recalcula y escribe `_SUCCESS.json` **al final**;
4. abre su run de MLflow con `idempotency_key = <run_key>:<etapa>[:<modelo>]` y **borra el run anterior con esa
   clave**: un reintento sustituye, no duplica.

**Qué garantiza.** Reintentos de Airflow (`retries`, backoff exponencial) y relanzar el DAG con la misma
`run_key` no duplican runs ni mezclan salidas a medias; si cambian los datos, la config o el commit, las
etapas afectadas (y las posteriores) se recalculan. Parámetro `force` para recalcular todo.
Probado en `tests/smoke_pipeline.py` y con `airflow dags test` (segunda ejecución: todo `SALTADA`).

**Límites.** El commit forma parte de la huella: cualquier commit invalida la caché (deliberado: el código
puede cambiar el resultado). Los fits en GPU (CatBoost) no son deterministas bit a bit.

---

## D8. Lógica de `GetBestModel()`

**Decisión.** (`src/training.py`)
1. **Filtros de seguridad:** sin error de entrenamiento, `decay ≤ 10 %`, `AUC validación ≥ 0.55`.
2. **Ranking por la métrica primaria de negocio** (D4).
3. **Empate práctico:** modelos a menos de `tie_tolerance = 0.005` de la mejor métrica son equivalentes;
   entre ellos gana mayor AUC, luego menor tiempo de entrenamiento, luego el nombre (determinismo).
4. Se evalúa sobre la **validación de los meses 1–6**. **Nunca** usa los meses 7–10: hacerlo los convertiría
   en datos de selección y el backtesting dejaría de ser una prueba honesta.

Se ejecuta en `select_hpo`, dentro del benchmark y de nuevo como tarea explícita `get_best_model`
(que además verifica que coincide con el campeón del benchmark antes de evaluar).
Si ningún modelo cumple los filtros, la tarea falla con un mensaje explícito en vez de elegir uno malo.

**Alternativa descartada.** El score compuesto de la P1 (`AUC × (1−decay) × factor_tiempo`) se conserva como
`GetBestModelScoreCompuesto` y como respaldo para corridas antiguas sin métrica de negocio.

**Límite.** La captura top-k sobre una validación pequeña es ruidosa; por eso la tolerancia de empate.

---

## D9. Periodicidad de ejecución en producción

**Decisión.** **Reentrenamiento mensual**, disparado cuando llega el CSV del mes nuevo (p. ej. el día 5 de cada
mes), más un **chequeo de degradación**: si el decay del último mes en backtesting supera `max_decay_percent`
se adelanta el reentrenamiento. El DAG mantiene `schedule=None`; el disparo lo hace una persona o un
planificador externo (cron/CI llamando a la API de Airflow con una `run_key` por mes, p. ej. `2026-11`).

**Por qué.** Los datos llegan como un archivo por mes, así que reentrenar con mayor frecuencia no aporta
información nueva; menos frecuencia deja al modelo envejecer. Usar `run_key = AAAA-MM` hace que relanzar el
mes retome el trabajo en vez de repetirlo (D7). Si se quisiera cron nativo bastaría `schedule='0 6 5 * *'`.

**Límite.** La frecuencia óptima debe confirmarse con la curva de decay de las 4 olas reales; si el AUC es
estable durante los cuatro meses, trimestral podría bastar.

---

## Resultados con datos reales (completar tras la corrida)

| Indicador | Valor |
|---|---|
| Campeón y `capture_rate_top_k` | _por completar_ |
| T secuencial / T paralelo / speed-up | _por completar_ |
| AUC validación / AUC promedio olas / decay por ola | _por completar_ |
| Tiempo HPO por modelo, RAM pico, tamaño del modelo | _MLflow, runs `hpo/<modelo>`_ |

> Las pruebas incluidas (`tests/smoke_pipeline.py`) usan datos sintéticos: validan el funcionamiento del
> pipeline, no el rendimiento del modelo.
