"""DAG de entrenamiento AutoML (Práctica 3).

validate_data ─► prepare_data ─► hpo.<9 modelos en paralelo> ─► select_hpo ─► benchmark
                                                                               │
                              register_champion ◄─ backtesting ◄─ get_best_model ◄┘

Decisiones (detalle y justificación en docs/decisiones_diseno.md):
- schedule=None: ejecución manual (D9: el reentrenamiento lo dispara una persona o un
  disparador externo; no hay cron dentro del DAG).
- D3 granularidad: una tarea por etapa y una tarea por modelo en HPO; el benchmark es una
  sola tarea porque mide secuencial vs paralelo dentro del mismo proceso.
- D2 cómputo: las 9 tareas de HPO corren en paralelo limitadas por el pool ``automl_compute``;
  el benchmark compara además secuencial vs joblib/loky con los mismos hiperparámetros.
- D7 idempotencia: cada tarea escribe en runs/<run_key>/<etapa>/ y se salta si ya terminó con
  la misma huella; los reintentos (retries) reutilizan el mismo run_key.
- La compuerta de validación falla SIN reintentos (AirflowFailException) y corta el DAG.
"""
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from airflow import DAG
from airflow.exceptions import AirflowFailException
from airflow.models.param import Param
from airflow.operators.python import PythonOperator
from airflow.utils.task_group import TaskGroup

# El código vive en el proyecto montado; PYTHONPATH lo cubre en Docker, esto cubre ejecución local.
PROJECT_ROOT = Path(os.environ.get('AUTOML_PROJECT_ROOT', Path(__file__).resolve().parents[1]))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

MODELOS = ['xgb', 'lgbm', 'catb', 'logistic_regression', 'random_forest', 'ridge_classifier',
           'adaboost', 'gradient_boosting_sklearn', 'extra_trees']
POOL = os.environ.get('AUTOML_POOL', 'automl_compute')

default_args = {
    'owner': 'mlops',
    'retries': int(os.environ.get('AUTOML_RETRIES', 2)),          # reintentos configurables por entorno
    'retry_delay': timedelta(seconds=int(os.environ.get('AUTOML_RETRY_DELAY_SECONDS', 60))),
    'retry_exponential_backoff': True,
    'max_retry_delay': timedelta(minutes=15),
    'execution_timeout': timedelta(hours=int(os.environ.get('AUTOML_TASK_TIMEOUT_HOURS', 4))),
}


def _overrides(params):
    over = {}
    if params.get('n_trials'):
        over.setdefault('hpo', {}).setdefault('optuna', {})['n_trials'] = int(params['n_trials'])
    if params.get('sample_fraction'):
        over['sample_fraction'] = float(params['sample_fraction'])
        over.setdefault('backtesting', {})['sample_fraction'] = float(params['sample_fraction'])
    if params.get('workers'):
        over.setdefault('parallel', {})['workers'] = int(params['workers'])
    return over


def ejecutar_etapa(etapa, modelo=None, **context):
    """Callable común: delega en src.stages, que ya es idempotente."""
    from src import stages
    from src.validation import DataValidationError
    params = context['params']
    run_key = params.get('run_key') or context['run_id']
    cfg = stages.cargar_config(params['config_path'], overrides=_overrides(params))
    try:
        result = stages.ejecutar(etapa, cfg, run_key, modelo, force=bool(params.get('force')))
    except DataValidationError as exc:
        raise AirflowFailException(str(exc))  # datos malos: reintentar no sirve
    # XCom liviano: los resultados completos viven en runs/<run_key>/ y en MLflow.
    return {'run_key': stages.sanear(run_key), 'etapa': etapa, 'modelo': modelo,
            'cached': bool(result.get('cached')), 'mlflow_run_id': result.get('mlflow_run_id')}


with DAG(
    dag_id='automl_training_pipeline',
    description='AutoML: validación, HPO (Optuna) por modelo, benchmark CPU/GPU, GetBestModel, backtesting y registro',
    schedule=None,                      # ejecución manual
    start_date=datetime(2026, 10, 1),
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    params={
        'config_path': Param('config/config.yaml', type='string', description='YAML de configuración del proyecto'),
        'run_key': Param('', type=['string', 'null'], description='Clave de idempotencia; vacío = run_id de Airflow. '
                         'Reusar una clave retoma una corrida sin recalcular lo ya terminado.'),
        'force': Param(False, type='boolean', description='Recalcular todas las etapas aunque ya existan'),
        'n_trials': Param(None, type=['integer', 'null'], description='Trials de Optuna por modelo (vacío = config)'),
        'sample_fraction': Param(None, type=['number', 'null'], description='Fracción de muestreo (vacío = config)'),
        'workers': Param(None, type=['integer', 'null'], description='Workers del benchmark paralelo (vacío = config)'),
    },
    tags=['mlops', 'automl', 'mcd402'],
    doc_md=__doc__,
) as dag:

    def tarea(etapa, task_id=None, modelo=None, **kwargs):
        return PythonOperator(task_id=task_id or etapa, python_callable=ejecutar_etapa,
                              op_kwargs={'etapa': etapa, 'modelo': modelo}, **kwargs)

    validate = tarea('validate_data')
    prepare = tarea('prepare_data')
    with TaskGroup('hpo', tooltip='Una tarea por modelo; paralelas, limitadas por el pool') as hpo_group:
        hpo_tasks = [tarea('hpo_model', task_id=m, modelo=m, pool=POOL) for m in MODELOS]
    select = tarea('select_hpo')
    bench = tarea('benchmark')
    best = tarea('get_best_model')
    backtest = tarea('backtesting')
    register = tarea('register_champion')

    validate >> prepare >> hpo_group >> select >> bench >> best >> backtest >> register
