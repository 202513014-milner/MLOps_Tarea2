"""Validación de datos como compuerta del DAG (punto extra).

Lee cada CSV por bloques (memoria acotada) y comprueba: existencia, esquema común,
target binario sin nulos, tasa de positivos razonable, mínimo de filas y fracción de
nulos por columna. Si algún chequeo es crítico falla con ``DataValidationError``;
el DAG lo convierte en fallo sin reintentos y las tareas posteriores no corren.
"""
import json
from pathlib import Path

import pandas as pd


class DataValidationError(Exception):
    """Los datos no cumplen el contrato mínimo para entrenar."""


DEFAULTS = {'min_rows': 1000, 'min_positive_rate': 0.001, 'max_positive_rate': 0.5,
            'max_null_fraction': 0.95, 'chunksize': 200_000, 'max_schema_drift': 0}


def validar_archivo(path, config, rules):
    target = config['target_col']
    sep, enc = config.get('csv_sep', ','), config.get('csv_encoding', 'utf-8')
    rows = pos = target_nulls = 0
    classes = set()
    nulls, columns = None, None
    for chunk in pd.read_csv(path, sep=sep, encoding=enc, chunksize=rules['chunksize'], low_memory=False):
        if columns is None:
            columns = list(chunk.columns)
            nulls = pd.Series(0, index=columns, dtype='int64')
        rows += len(chunk)
        nulls += chunk.isna().sum()
        if target in chunk:
            col = chunk[target]
            target_nulls += int(col.isna().sum())
            classes |= set(col.dropna().unique().tolist())
            pos += int((col == 1).sum())
    return {'file': Path(path).name, 'rows': rows, 'columns': columns or [], 'positives': pos,
            'positive_rate': (pos / rows) if rows else None, 'target_nulls': target_nulls,
            'target_classes': sorted(classes),
            'null_fraction': {} if not rows else {c: float(v) / rows for c, v in nulls.items()}}


def validar_datos(config, report_path=None):
    rules = {**DEFAULTS, **(config.get('validation') or {})}
    root = Path(config['input_dir'])
    temporal = config['temporal']
    files = list(temporal['development_files']) + list(temporal['backtesting_files'])
    errors, warnings, per_file = [], [], []
    for name in files:
        path = root / name
        if not path.is_file():
            errors.append(f'{name}: no existe en {root}')
            continue
        try:
            info = validar_archivo(path, config, rules)
        except Exception as exc:  # CSV ilegible/corrupto
            errors.append(f'{name}: no se pudo leer ({type(exc).__name__}: {exc})')
            continue
        per_file.append(info)
        if info['rows'] < rules['min_rows']:
            errors.append(f'{name}: {info["rows"]} filas < mínimo {rules["min_rows"]}')
        if config['target_col'] not in info['columns']:
            errors.append(f'{name}: falta la columna target "{config["target_col"]}"')
        else:
            if info['target_nulls']:
                errors.append(f'{name}: target con {info["target_nulls"]} nulos')
            if not set(info['target_classes']).issubset({0, 1}):
                errors.append(f'{name}: target no binario {info["target_classes"]}')
            rate = info['positive_rate']
            if rate is not None and not rules['min_positive_rate'] <= rate <= rules['max_positive_rate']:
                errors.append(f'{name}: tasa de positivos {rate:.4f} fuera de '
                              f'[{rules["min_positive_rate"]}, {rules["max_positive_rate"]}]')
        empty = [c for c, f in info['null_fraction'].items() if f > rules['max_null_fraction']]
        if empty:
            warnings.append(f'{name}: columnas casi vacías (> {rules["max_null_fraction"]:.0%} nulos): {empty[:8]}')
    if per_file:
        ref = set(per_file[0]['columns'])
        for info in per_file[1:]:
            drift = ref ^ set(info['columns'])
            if len(drift) > rules['max_schema_drift']:
                errors.append(f'{info["file"]}: esquema distinto a {per_file[0]["file"]} '
                              f'({sorted(drift)[:8]})')
    report = {'ok': not errors, 'errors': errors, 'warnings': warnings, 'rules': rules,
              'files': [{k: v for k, v in f.items() if k not in ('null_fraction', 'columns')}
                        for f in per_file], 'n_columns': len(per_file[0]['columns']) if per_file else 0}
    if report_path:
        Path(report_path).parent.mkdir(parents=True, exist_ok=True)
        Path(report_path).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    if errors:
        raise DataValidationError('Validación de datos fallida:\n - ' + '\n - '.join(errors))
    return report
