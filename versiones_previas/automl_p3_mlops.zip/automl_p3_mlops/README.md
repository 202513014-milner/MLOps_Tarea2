# AutoML — Práctica 3: pipeline orquestado y reproducible (MLOps)
Extensión de la P1 y la P2 (Milner Quispe, Rosabel Guzman y Kimberly Olivos). El AutoML de la P2 (HPO, benchmark
CPU/GPU y backtesting) ahora corre como un DAG de **Airflow**, con experimentos en **MLflow**, todo en **Docker**.
Las decisiones de diseño D1–D9 y su justificación están en [`docs/decisiones_diseno.md`](docs/decisiones_diseno.md).

## Arranque rápido (Docker)
```bash
# 1. Colocar p1_extrac.csv ... p10_extrac.csv en data/input/ (o fijar DATA_DIR en .env)
python scripts/up.py                  # genera .env (commit, imagen), construye y levanta todo
# Airflow: http://localhost:8080 (admin / admin)    MLflow: http://localhost:5000
# En Airflow: DAG automl_training_pipeline -> Trigger DAG w/ config (opcional: run_key, n_trials, ...)
python scripts/up.py --down           # detener (los volúmenes conservan resultados)
```
GPU (opcional, NVIDIA Container Toolkit): `python scripts/up.py --gpu`.

## Qué hace el DAG (`dags/automl_training_dag.py`, `schedule=None`, reintentos configurables)
`validate_data → prepare_data → hpo.<9 modelos en paralelo> → select_hpo → benchmark → get_best_model → backtesting → register_champion`

| Tarea | Salida principal |
|---|---|
| `validate_data` | Compuerta de datos (esquema, target binario, tasa de positivos, nulos). Si falla, el DAG se corta sin reintentos. Calcula el hash de los CSV. |
| `prepare_data` | Muestreo 10 % por mes y split 70/30 (solo meses 1–6). |
| `hpo.<modelo>` | Optuna por modelo (una tarea por modelo, limitadas por el pool `automl_compute`). |
| `select_hpo` | Consolida los 9 resultados y aplica `GetBestModel()`. |
| `benchmark` | Entrena los 9 modelos en secuencial y en paralelo (CPU/GPU) con los mismos hiperparámetros. |
| `get_best_model` | Campeón por métrica de negocio (captura de ventas en el top 10 %), sin usar meses 7–10. |
| `backtesting` | Evalúa el campeón fijo en los meses 7–10 (decay por ola). |
| `register_champion` | Registra el modelo en el Model Registry de MLflow y promueve el alias `champion` si no es peor que el vigente. |

## Trazabilidad e indicadores operativos
Cada run de MLflow registra: **commit de git, hash de los datos, imagen Docker, configuración efectiva y la ejecución
del DAG** (tags y artefactos), más CPU, RAM, GPU (si existe), tiempos y tamaño del modelo (`compute.*`, `model_size_mb`
y series temporales `ts.*`). Las tareas son idempotentes: reintentar o relanzar con la misma `run_key` no duplica runs.

## Ejecutar sin Airflow / pruebas
```bash
pip install -r requirements.txt
python -m src.stages all --config config/config.yaml --run-key local     # las 8 etapas en un proceso
python tests/smoke_pipeline.py        # integración con datos sintéticos (sin Airflow ni Docker)
python tests/smoke_parallel.py && python tests/smoke_backtesting.py       # pruebas de la P2
```
`main.py` conserva la ejecución por etapas de la P2 (HPO/paralelo/backtesting en un solo proceso).

## Estructura nueva
```
dags/automl_training_dag.py   DAG de Airflow
src/stages.py                 etapas idempotentes (una función por tarea)
src/tracking.py               MLflow: runs idempotentes, tags de trazabilidad
src/provenance.py             commit, hash de datos, imagen, contexto del DAG
src/compute_logger.py         CPU/RAM/GPU/tiempos/tamaño del modelo
src/validation.py             compuerta de datos
src/ops_metrics.py            métrica de negocio y decay (D1, D4)
Dockerfile, Dockerfile.mlflow, docker-compose.yml (+ .gpu.yml), scripts/up.py
docs/decisiones_diseno.md     D1–D9
```

---
# Documentación de la Práctica 2 (se conserva)
# AutoML — Práctica 2, primera etapa: HPO
Extensión de la P1 de Milner Quispe, Rosabel Guzman y Kimberly Olivos.

## Ejecutar
Python 3.11 recomendado. Descargar los diez CSV del Drive del curso y colocarlos en `data/input/` (no se incluyen). No se descargan automáticamente: la P1 también requería colocarlos allí.

```bash
pip install -r requirements.txt
python main.py --input data/input --config config/config.yaml
```

## Separación y muestra
`temporal.development_files` enumera p1–p6; `backtesting_files` enumera p7–p10. Confirmar que este orden corresponde a los meses reales. Si existe una columna mensual, configurar `period_col` para validar los seis periodos de desarrollo. Los cuatro futuros solo se comprueban por existencia: no se leen, transforman ni muestrean aún. No se inventan meses a partir del nombre.

Se conserva `sample_fraction: 0.10`: muestra aleatoria estratificada por target en cada mes, luego split 70/30 estratificado por clase dentro de cada mes. Así se conservan aproximadamente la composición mensual y las tasas de positivos; esto no garantiza representar todas las subpoblaciones. La lectura carga un CSV completo a la vez y concatena únicamente las muestras de desarrollo.

## HPO
Nueve modelos del ZIP original: XGBoost, LightGBM, CatBoost, regresión logística, RidgeClassifier, random forest, AdaBoost, GradientBoosting de sklearn y ExtraTrees. Grillas pequeñas configurables: 60 combinaciones; 3 folds = 180 ajustes CV y nueve refits. HPO usa únicamente el 70% de desarrollo. El 30% restante es validación para selección del campeón, no prueba independiente final. CV estratificada interna conserva el enfoque P1; no es validación temporal. Los cuatro meses futuros darán la evaluación temporal posterior.

Imputación y codificación se ajustan dentro de cada fold usando Pipeline/ColumnTransformer. Se sustituye LabelEncoder por OHE para no imponer orden a categorías. Escalado numérico incluido, útil para regresión logística; variables identificadoras y periodo se excluyen. El modelo guardado contiene también sus transformaciones y acepta DataFrames con las columnas originales de predictores.

`src/training.py`, `evaluation.py`, `registry.py` y `GetBestModel()` se conservan; main utiliza la nueva ruta HPO. GetBestModel conserva los filtros y score compuesto de P1. Las funciones antiguas de entrenamiento permanecen como referencia pero no son llamadas por main. No se repite una segunda CV tras HPO. El AUC CV elegido es optimista por selección de parámetros; no es CV anidada.

Los tiempos de búsqueda + refit y del refit se muestran por modelo y en la tabla final. Ridge usa decision_function para AUC y KS, y predict para F1; no se inventan probabilidades. Se conservan los nombres originales de los nueve modelos.

Cada corrida incluye modelos, metadata con `hpo`, CSV de todos los candidatos y `results_summary.json` con archivos, filas y tasas del muestreo. Las versiones reales se registran; requirements usa rangos compatibles y no un lock reproducible exacto.

## Paralelismo CPU/GPU y switches
`modules.hpo` y `modules.parallel` activan las etapas; `modules.backtesting` activa la evaluación temporal. Por defecto se ejecuta solo backtesting; puede usar los presets para las otras etapas. El módulo se implementa en `src/parallel.py` con joblib/loky (procesos, compatible con Windows y ejecución CLI en Colab).

```yaml
modules:
  hpo: false
  parallel: true
  backtesting: false
parallel:
  workers: 2
  hpo_run_dir: "data/output/REEMPLAZAR_FECHA_DE_TU_CORRIDA_HPO"
```

Apuntar a una corrida HPO REAL de nueve modelos generada con los mismos datos y configuración. Copiar esa carpeta de salida anterior al nuevo proyecto. `null` busca la última corrida compatible entre las subcarpetas inmediatas de data/output. No toma los parámetros de ejemplo de la grilla como ganadores y no ejecuta GridSearch en esta etapa. Con ambas etapas activadas, usa los resultados HPO recién generados. Los parámetros guardados se aplican a estimadores nuevos, con los pesos por desbalance y semillas de HPO. Se rechazan fuentes incompletas o con configuración de muestreo/partición incompatible; cambiar físicamente los CSV no se detecta por checksum y requiere nueva HPO.

```bash
python main.py --input data/input --config config/parallel_only.yaml
python main.py --input data/input --config config/hpo_only.yaml
python main.py --input data/input --config config/full.yaml
```

La muestra 10%, split 70/30 y meses 1–6 siguen iguales; 7–10 no se leen. El preprocesamiento se vuelve a ajustar únicamente en train. El benchmark NO es HPO ni usa CV: entrena una vez cada modelo secuencialmente y otra vez en paralelo con los mismos HP, datos, semillas y dispositivo. Se conserva GetBestModel y su política. Workers >=2, estimadores CPU con un hilo y BLAS limitado para evitar sobresuscripción. El número de procesos puede superar los núcleos disponibles y resultar más lento; ajustar según memoria y CPU.

GPU detectada mediante nvidia-smi o CatBoost y comprobada con fits cortos reales antes del cronómetro. XGBoost usa hist + cuda:0; CatBoost task_type=GPU, devices=0. LightGBM prueba CUDA y después OpenCL; si la instalación no ofrece backend GPU, queda en CPU con motivo explícito. Los seis estimadores sklearn usan CPU. No se usa cuML (punto extra no implementado). Tener GPU detectada sin ningún backend funcional genera error, no una falsa corrida GPU. Sin GPU, todos entrenan en CPU. Si falla el entrenamiento real no se cambia silenciosamente el dispositivo: se detiene la comparación para no mezclar condiciones.

Un lock compartido evita dos fits GPU simultáneos en el dispositivo 0; CPU puede solaparse con GPU. Se registran tiempos de fit, espera de GPU, tiempo de proceso y PID, además de totales secuencial/paralelo y speed-up. Los totales incluyen ajuste de preprocesamiento, fit y overhead de despacho/transferencia de resultados, y excluyen carga, HPO, preflight, evaluación y guardado. Es un benchmark de una repetición con orden secuencial primero, no una estimación estadística ni comparación CPU/GPU. El speed-up puede ser menor que 1. CatBoost GPU no garantiza determinismo exacto; los AUC pueden variar ligeramente.

Salidas en `data/output/parallel/FECHA`: nueve pipelines .pkl, nueve metadata .json con hardware, origen HPO, tiempos, resultados y README con tabla de tiempos reales. El README raíz se actualiza al finalizar el benchmark con las mismas tablas y análisis. No se adjuntan tiempos o ganadores de datos reales inventados. Un fallo no produce resumen exitoso.

### Uso Colab/Windows
Python 3.11 recomendado; CLI con guard `if __name__ == '__main__'` para multiprocessing. En Colab seleccionar GPU en Runtime y ejecutar main vía subprocess desde el notebook. Cambiar el nombre del ZIP cargado no requiere cambiar código. Instalar requirements no instala una versión GPU de LightGBM por compilación; XGBoost/CatBoost proporcionan la ruta GPU principal. Requisitos CUDA/drivers dependen de la versión instalada. Si las versiones antiguas y actuales difieren, registrar ese cambio en la comparación.

Referencias oficiales:
- https://xgboost.readthedocs.io/en/stable/gpu/
- https://catboost.ai/docs/en/references/training-parameters/processing-unit
- https://lightgbm.readthedocs.io/en/stable/Installation-Guide.html
- https://joblib.readthedocs.io/en/stable/generated/joblib.Parallel.html

## Alcance
HPO, paralelismo y backtesting implementados. El proyecto conserva módulos P1 como referencia; main ejecuta las etapas P2 activadas, no las dos rondas antiguas. El HPO actual mantiene CPU; esta etapa de benchmark usa automáticamente GPU cuando se dispone de backend funcional.

## Backtesting — tercera etapa
`src/backtesting.py` reutiliza `muestreo_estratificado` de preprocessing, `obtener_scores` de evaluation y funciones de registry. Lee el campeón que ya eligió GetBestModel y su pipeline .pkl: no llama fit, HPO ni benchmark. En solo backtesting, no carga CSV 1–6. Al ejecutar todo el flujo, usa el campeón de paralelismo de esa misma corrida.

```yaml
modules:
  hpo: false
  parallel: false
  backtesting: true
backtesting:
  source_run_dir: "data/output/parallel/FECHA_DE_TU_CORRIDA"
  cutoff_file: "p6_extrac.csv"
  cutoff_period: null
  sample_fraction: 0.10
```

Copiar la corrida exitosa con results_summary.json, metadata y .pkl del campeón al nuevo proyecto. Indicar su ruta real (absoluta o relativa). null busca la última corrida de paralelismo con campeón; si no existe, busca HPO. La ruta explícita es preferible para trazabilidad. No debe apuntar a la carpeta de backtesting ni al archivo .pkl individual. No cargar pickles de terceros no confiables.

El corte se configura en cutoff_file; se valida que sea el último archivo de desarrollo del campeón, porque cambiarlo requiere reentrenar. Las cuatro olas corresponden a los archivos reservados en el orden declarado en YAML. No se inventan fechas. Para verificar cronología: configurar temporal.period_col con la columna mensual real y backtesting.cutoff_period con YYYY-MM; también se puede derivar el corte de development_periods guardados. Si no existe columna, declarar temporal.file_periods con meses reales, incluyendo el archivo de corte y los cuatro futuros, y cutoff_period. Sin fechas configuradas, chronology_verified=false y se reporta explícitamente el orden por archivos como supuesto no verificado. Periodos verificados deben corresponder exactamente a T+1..T+4.

Se toma muestra estratificada del 10% por mes y target, configurable independientemente. No se crean splits nuevos ni se ajustan encoders: se aplica el pipeline guardado. El campeón conserva su entrenamiento en el 70% de la muestra de seis meses; esta etapa NO hace refit sobre los seis meses completos. Se evalúa con origen fijo, sin reentrenamiento entre olas, conforme a la interpretación acordada de entrenar hasta T y evaluar T+1..T+4. No es walk-forward con ventana de entrenamiento creciente.

Decay % = 100*(AUC_validación - AUC_ola)/AUC_validación. Un decay negativo indica mejora. El AUC de referencia es el auc_test del campeón en su metadata. Una ola de una sola clase o vacía se marca con AUC/decay null, reporte parcial y no se inventa 0.5; el promedio solo usa olas válidas y se muestra su cantidad. No se modifica GetBestModel usando el promedio futuro: hacerlo convertiría estos meses en datos de selección (el punto extra no está implementado).

Cada corrida genera en data/output/backtesting/FECHA: backtesting_results.json, tabla CSV, auc_por_ola.png y README con tabla/gráfico. El README raíz también se actualiza con resultados reales. El notebook notebooks/backtesting_analysis.ipynb lee el JSON y presenta tabla de AUC/decay, gráfico por ola, línea AUC de validación y línea 0.5. Se puede ejecutar en Colab subiendo solo ese JSON, sin repetir entrenamiento. No se adjuntan resultados de datos reales.

```bash
python main.py --input data/input --config config/config.yaml
# Todas las etapas:
python main.py --input data/input --config config/full.yaml
```

Se corrigió la lectura de JSON antiguos Windows cp1252 y la escritura de nuevos JSON UTF-8. Esto incluye reutilización de corridas HPO previas.
